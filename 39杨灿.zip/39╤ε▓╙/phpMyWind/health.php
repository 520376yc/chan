<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/health.css">
<link rel="stylesheet" href="css/common.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>
	<div class="solu">
			<img src="images/detailsNav.jpg" alt="">
       </div>
       <div class="solution">
	    <span>解决方案</span>
	    <p>您当前所在位置:首页>解决方案</p>
	</div>
	    <div class="s-cutting"></div>
	    <div class="s-cutting"></div>
	    <div class="n-content">
			<div class="row">
			<div class="col-lg-12 col-md-12 col-xs-12" >
				<div class="p-title">
  			<h1>区域卫计生管理</h1>
  			   </div>
  			<div class="p-info">
				更新时间：<time datetime="">2017-6-25</time>
				点击次数：5200次
  			</div>
  			<div class="n-content">
			<div class="row">
			<div class="col-lg-12 col-md-12 col-xs-12" >
			 <div class="p-referral">
  			随着社会的不断发展和进步，区域卫生信息化正面临着各种新挑战。基于健康管理及卫生服务领域自身固有的特点和复杂性，卫生信息化发展整体水平落后于其他行业。为加快医疗卫生信息化的发展，国家卫计委将卫生信息化建设作为新医改的核心之一，并且在“十二五”规划中制订了卫生信息化具体的路线图。奥昇信息结合自身优势，自主设计实现以电子病历和健康档案为中心的区域医疗信息化系统解决方案。
  			</div>
  			<div class="n-content">
				<div class="row">
			  		<div class="col-lg-12 col-md-12 col-xs-12" >
			  		<div class="p-font2">
			<span>互联网+监督是践行党的群众路线，密切干群关系最直观的体现。其优势表现在通过大数据分析对各种数据进行排查、提炼各种有效信息，协助纪律检查部门缩小排查范围，有针对性的对各种违纪违章情况进行查处。并通过互联网的手段，使得群众亦可不出家门便对掌握的信息进行反馈和跟踪。这是一种趋势，是适应大数据时代下网络监管的具体措施。</span><br/><br/>
			<span>我公司自主研发的“互联网+监督”系统平台，通过各种数据的处理、整合、分析从而实现自动化分析，为纪律检查和全民监督提供有效的途径和手段。</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>一、前台网站包括四大功能：政民互动、民生监督、扶贫攻坚、信息公示。</span><br/><br/>
			<span>政民互动：我要投诉、我要举报、我要点赞、你问我答、反馈公示、随手拍；</span><br/><br/>
			<span>民生监督：惠民政策、民生资金、监督机构、办事流程、与我相关；</span><br/><br/>
			<span>扶贫攻坚：扶贫政策、精准扶贫、精准脱贫、精准识贫、贫困人口分布、干部帮扶等；</span><br/><br/>
			<span>信息公示：政策中心、村务公开、项目公示、曝光台。</span><br/><br/>
			<span>二、管理后台包括：政民互动、政务公示、民生监管、扶贫监管、基础数据、社区地图、数据统计、系统管理等。</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>民生监管：民生监督组、数据识别（数据碰撞，包括自动识别和手动识别）、各部门补贴情况；</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>扶贫监管：精准识贫（未脱贫人口）、精准扶贫、精准脱贫（脱贫人口）、干部帮扶、众筹扶贫、雨露计划；</span><br/><br/>
			<span>监督平台包括两大部分：前台网站和管理后台。</span><br/><br/>
			<span>系统管理：辖区管理、角色管理、部门管理、用户管理、考核用户管理、操作日志、登陆日志。</span><br/><br/>
	     </div>
	     <div class="edit">(编辑：admin)</div>
	     <div class="preface">
			<ul class="up">
				<li>上一篇：区域卫计生管理</li>
				<li>下一篇：已经没有了</li>
			</ul>
			</div>
			<div class="down">
				<img src="images/xx.png">收藏
				<img src="images/ff.png">打印
			</div>
			<div class="review">
				<span>
				<i>0</i>
				条评论</span>
			</div>
			<div class="discuss">
				
					<div class="msg"><textarea>说点什么吧。。。</textarea></div>
					<div class="toobl">不想登录？直接点击发布即可作为游客留言。</div>
					<div class="toob2"><input type="button" value="发布"></div>
			
			</div>
			</div>     
			 </div>

			     </div>
			</div>     
			 </div>
			     </div>
		</div>     
			 </div>
			     </div>
<?php require_once('footer.php'); ?>

</body>
</html>