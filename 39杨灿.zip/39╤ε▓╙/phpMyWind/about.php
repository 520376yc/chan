<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 2 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>

<link rel="stylesheet" type="text/css" href="css/new.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
</head>
<body style="margin-left: -50px;">
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="container">
		<div class="row">
             <div class="col-lg-12 col-md-12 col-xs-12" >
					 <div class="consult">
                  <img src="image/4.jpg">
					</div>
				</div>
             </div>
          </div>

<div class="coansultings">
<p>咨询中心</p>
</div>
<div class="new">

<a href="solve.html">解决方案</a>
	</div>
	    <<div class="container">
		<div class="row">
		<div class="col-lg-12 col-md-12 col-xs-3" >
 
			
	
				<?php
			$dosql->Execute("SELECT * FROM `#@__infolist`  WHERE classid=4 and flag='c' ");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>


                                 <div class="consult">
					<div class="details"">
							<img src="<?php echo $row['picurl']; ?>" >
						
					

							<h1><a href="<?php echo $gourl ?>"><?php echo $row['title']; ?></a></h1>
							<span datetime="">2017-6-18</span><br/>
							<p ><?php echo $row['content']; ?></p>
						</div>
					</div>
				<?php
			}
			?>
			
			
				</div>
	    	</div>
	    	
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>