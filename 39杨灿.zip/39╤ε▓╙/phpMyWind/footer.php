
<div class="base">
<?php

echo GetQQ();

//将流量统计代码放在页面最底部
$cfg_countcode;

?>
	<div class="base1"><img src="image/header-logo.png"></div>
	<div class="base2"><img src="image/houpu_code.png" class="tp"></div>
<p>合作热线：4000-12345697-456
<p>opyright © 2014 - 2017 aorise All Rights Reserved</p>
<p>本栏目文字内容归aorise.cn 所有,任何单位及个人未经许可，不得擅自转摘使用</p>
</div>
