<?php require_once(dirname(__FILE__).'/include/config.inc.php'); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>

<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet"  href="css/index.css">
<link rel="stylesheet"  href="css/common.css">
<link rel="stylesheet"  href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="banner">
	<div id="slideplay">
		<ul>
			<?php
			$dosql->Execute("SELECT * FROM `#@__infoimg` WHERE classid=13 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<li><a href="<?php echo $gourl; ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>" /></a></li>
			<?php
			}
			?>
		</ul>
	</div>
</div>
<!-- /banner-->
<!-- 解决方案 -->
	<div class="more">
	    <div class="more1">
	    	<a href="project.html">解决方案/Solutions More</a>
	    </div>
		<div class="s-wire"></div>
<div class="container">
    <div class="row">
    <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=14 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,3");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>
        <div class="col-md-4 col-lg-4">
        <div class="s-content-image">
						<div class="s-image">
							<a href="<?php echo $gourl ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"></a>
						</div>
						<div class="title"><span<?php echo $row['picurl']; ?>"><?php echo $row['title']; ?></span></div>
				      </div>
        </div>
        <?php
			}
			?>
    </div>
</div>
</div>
<!-- end解决方案 -->

 <!-- 解决方案 --> -->
	<div class="more">
	    <div class="more1">
	    	<a href="project.html">关于我们/Solutions More</a>
	    </div>
		<div class="s-wire"></div>
		<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=15 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,4");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>
        <div class="col-md-3 col-lg-3">
        <div class="s-content-image">
						<div class="s-image">
							<a href="<?php echo $gourl ?>"><img src="<?php echo $row['picurl']; ?>" alt="<?php echo $row['title']; ?>"></a>
						</div>
						<div class="title"><span<?php echo $row['picurl']; ?>"><?php echo $row['title']; ?></span></div>
				      </div>
        </div>
        <?php
			}
			?>
    </div>
</div>
</div>
<!-- end解决方案 -->

 <!-- 解决方案 --> 
	<div class="more">
			<div class="more1">
				<a href="news.php">新闻资讯/NEWS More</a>
			</div>
			</div>
			<div class="aorise-wrap"></div>
			<div class="n-content">
				<div class="row">
			<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4  AND delstate='' AND flag=''AND checkinfo=true ORDER BY orderid DESC ");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>
					<div class="col-lg-6 col-md-6 col-xs-6" >
					<div class="n-content-image">
						<a href="<?php echo $gourl ?>"><img src="<?php echo $row['picurl']; ?>"></a>
					</div>
					<div class="n-content-image"><p><?php echo $row['description']; ?></p></div>
					</div>
	<?php
			}
			?>
			<div class="col-lg-6 col-md-6 col-xs-6" >
				 <div class="list">
					<ul>
					<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=4 AND flag='a' AND delstate='' AND checkinfo=true ORDER BY orderid DESC ");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'newsshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'newsshow-'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
			?>
						<li><p></p><a href="<?php echo $gourl ?>"><?php echo $row['title']; ?></a><time datetime="">2017-6-18</time></li>"

			<?php
			}
			?>
					</ul>
				</div>
					</div>
				</div>
			</div>
	</div>

<!-- end解决方案 -->

<?php require 'footer.php'; ?>
</body>
</html>
