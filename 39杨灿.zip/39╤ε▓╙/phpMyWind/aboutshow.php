<?php require_once(dirname(__FILE__).'/include/config.inc.php'); 


?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet" href="css/about.css">
<link rel="stylesheet" href="css/common.css">
<link rel="stylesheet" href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/slideplay.js"></script>
<script type="text/javascript" src="templates/default/js/srcollimg.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".imgwrap li img").LoadImage({width:60,height:45});
	$(".newsfocus div img").LoadImage({width:60,height:60});
});
</script>
</head>
<body>
<!-- 导航图 -->
<div class="pilotage">
<div class="container">
		<div class="row">
	<?php
			$dosql->Execute("SELECT * FROM `#@__infolist`  WHERE classid=2 AND delstate='' AND checkinfo=true AND flag='f'");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
			<img src="<?php echo $row['picurl']; ?>" alt="" />
			<?php
			}
			?>
             </div>
          </div>
 </div>
<!-- end导航图 -->
<!-- 关于我们 -->
	<div class="container">
		<div class="row solution">
		    <span>公司简介</span>
		    <p>您当前所在位置:首页>关于我们</p>
	</div>
	<div class="row left">
		<div class="s-title">
	    <a href="solve.html">关于我们</a>
		</div>
	    <div class="s-wire"></div>
	
			<div class="col-md-3 col-md-3 col-xs-3">
				<div class="head">
					<p>关于我们/About Us</p>
				</div>
				<ul>
				<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=2 AND flag='a' AND  delstate='' AND checkinfo=true ORDER BY orderid ASC");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl']=='' and $cfg_isreurl!='Y')
						$gourl = 'aboutshow.php?cid='.$row['classid'].'&id='.$row['id'];
					else if($cfg_isreurl=='Y')
						$gourl = 'aboutshow'.$row['classid'].'-'.$row['id'].'-1.html';
					else
						$gourl = $row['linkurl'];
				
			?>
			<li><a href="<?php echo $gourl?>"><?php echo $row['title'] ?></a></li>
			<?php
		}
		?>
				</ul>
			</div>
        <?php
			$dosql->Execute("SELECT * FROM `#@__infolist`  WHERE classid=2 AND delstate='' AND checkinfo=true AND flag='h'");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
				<div class="col-lg-9 col-md-9 col-xs-9 aaa">
				<?php echo $row['content']; ?>	
				</div>
					<?php
			}
			?>
		</div>
	</div>
<?php require_once('footer.php'); ?>

</body>
</html>