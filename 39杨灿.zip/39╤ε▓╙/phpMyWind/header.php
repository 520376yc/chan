 <div class="header-home navbar-fixed-top">
      <div class="container">
        <div class="row">
            <div class="col-lg-3 col-md-3 col-xs-3">
               <div class="header-logo">
                 <img src="image/header-logo.png" alt="头部图片"/>
              </div>
            </div>
            <div class="col-lg-9 col-md-9 col-xs-9">
                <div class="header-nav">
                    <ul>
                    <?php echo GetNav(); ?>
                    </ul>
             </div>
            </div>
        </div>
      </div>
    </div>