<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 5 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>

<link rel="stylesheet" type="text/css" href="css/show.css">
<link rel="stylesheet" href="css/bootstrap.min.css">

	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".product_list li img").LoadImage({width:220,height:150});
});
</script>
</head>
<body >
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="subBanner"> <img src="image/9.jpg" /> </div>
<!-- /banner-->
<!-- notice-->

<!-- /notice-->
<!-- mainbody-->

	<div class="new">
		<a href="">关于我们</a>
	</div>
	</div>
      </div>
    </div>


<div class="container">
    <div class="row">
    <div class="picture">
    <?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=5 AND delstate='' AND checkinfo=true ORDER BY orderid DESC LIMIT 0,5");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
        <div class="col-md-4 col-lg-4">
        <div class="s-content-image">
						<div class="s-image">
							<img src="<?php echo $row['picurl']; ?>"> <p><?php echo $row['title']; ?></p>
						</div>
						<div  <?php echo $row['picurl']; ?>"> </div>
				      </div>
        </div>
        <?php
			}
			?>
    </div>
</div>
</div>

<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>