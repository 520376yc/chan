<?php
require_once(dirname(__FILE__).'/include/config.inc.php');

//初始化参数检测正确性
$cid = empty($cid) ? 8 : intval($cid);
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<?php echo GetHeader(1,$cid); ?>
<link href="templates/default/style/webstyle.css" type="text/css" rel="stylesheet" />
<link rel="stylesheet"  href="css/bootstrap.min.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<link  rel="stylesheet" type="text/css" href="css/aboutUs.css">
<script type="text/javascript" src="templates/default/js/jquery.min.js"></script>
<script type="text/javascript" src="templates/default/js/loadimage.js"></script>
<script type="text/javascript" src="templates/default/js/top.js"></script>
<script type="text/javascript">
$(function(){
    $(".caselist a.img img").LoadImage({width:100,height:80});
});
</script>
</head>
<body>
<!-- header-->
<?php require_once('header.php'); ?>
<!-- /header-->
<!-- banner-->
<div class="subBanner"> <img src="image/15.jpg" /> </div>
<!-- /banner-->
<!-- notice-->
<div class="subnotice"><strong>网站公告：</strong><?php echo Info(1); ?></div>
<!-- /notice-->
<!-- mainbody-->
<div class="subBody">
	<div class="subTitle"> <span class="catname"><?php echo GetCatName($cid); ?></span> <span class="fr">您当前所在位置：<?php echo GetPosStr($cid); ?></span>
		<div class="cl"></div>
	</div>



<div class="new1">
			
	<div class="gyw"><br><p>关于我们/About US</p></div>
	<div class="bee">
		<ul>	
			<li><a href="#">公司简介</a></li>
			<li><a href="#">荣誉资质</a></li>
			<li><a href="#">企业文化</a></li>
			<li><a href="#">董事长致辞</a></li>
			<li><a href="#">公司风采</a></li>
			<li><a href="#">合作伙伴</a></li>
			<li><a href="#">公司地址</a></li>
		</ul>
	</div>
</div>
</div>
<div class="container">
		<div class="row">
             <div class="col-lg-12 col-md-12 col-xs-12" >
					 <div class="consult">
<div class="font">

					<?php
			$dosql->Execute("SELECT * FROM `#@__infolist` WHERE classid=15 AND flag='' AND delstate='' AND checkinfo=true ORDER BY orderid DESC ");
			while($row = $dosql->GetArray())
			{
				if($row['linkurl'] != '')$gourl = $row['linkurl'];
				else $gourl = 'javascript:;';
			?>
						<p><?php echo $row['description']; ?></p>

			<?php
			}
			?>
	     </div>
	     </div>
	       </div>
	         </div>



<!-- /mainbody-->
<!-- footer-->
<?php require_once('footer.php'); ?>
<!-- /footer-->
</body>
</html>